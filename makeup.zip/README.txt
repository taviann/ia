According to config file...

$servername = 'localhost';
$username = 'root';
$password = 'root';
$db = 'makeup';

database script is makeup_products.sql.